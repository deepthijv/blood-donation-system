<?php
$db=new PDO('mysql:host=localhost;dbname=blood_donation','','');
 ?>
